<?php
use App\Core\App;
echo var_dump(App::get('config')['share']['tw-text']) ;
exit;