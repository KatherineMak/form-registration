<?php

namespace App\Models;

use App\Core\Model as Model;

class Participaint extends Model
{

}