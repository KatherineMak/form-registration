<?php require('partials/head.php'); ?>
<?php require('partials/map.php'); ?>
    <div id="form">
    </div>
<?php require('partials/footer.php'); ?>