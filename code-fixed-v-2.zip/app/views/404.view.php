<?php require('partials/head.php');?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>Page not found 404</h1>
            <img src="../public/images/404.jpg"  height="700" width="1400" alt="Photo of Page Not Found 404">
        </div>
    </div>
</div>

<?php require('partials/footer.php'); ?>
