<!-- JavaScripts -->
<!-- Подключение jQuery плагина Masked Input -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.0/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="public\js\jquery.maskedinput.min.js"></script>
<script src="public\js\ajaxForm.js"> </script>

<script>
    // $(document).ready(function($) {
    //
    //     $(document).on('click', '#birthday', function () {
    //         $("#birthday").datepicker({
    //             showOn: 'focus',
    //             altFormat: "yy/mm/dd",
    //             dateFormat: "yy/mm/dd",
    //             minDate: '1940/12/31',
    //             maxDate: '2020/12/31',
    //             changeMonth: true,
    //             changeYear: true,
    //             yearRange: '1950:2019'
    //         }).focus();
    //     }).on('focus', '#birthday', function () {
    //         //$("#birthday").mask('9999/99/99');
    //     });
    //
    //
    //     $("#phone").mask("+9(999) 999-9999");
    // });
</script>
</body>
</html>