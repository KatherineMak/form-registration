<?php require('partials/head.php'); ?>
<?php require('partials/map.php'); ?>

<div class="container">
    <div class="home-card row justify-content-md-center" id="form">
            <div class="col-sm-5"><h4 class="card-title">Fill form to take part in the conference</h4></div>

            <div class="col-sm-3"><button onclick="ajaxForm.showIndexForm()" type="submit" class="btn btn-info">Registration</button></div>
    </div>
</div>

<?php require('partials/footer.php'); ?>
